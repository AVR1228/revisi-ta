-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2025 at 12:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','Manajemen','Pegawai') NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created_at`, `updated_at`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 'admin', '2025-10-30 03:11:54', '2025-10-30 03:11:54'),
(2, 'najib', 'd31b35b1dd9bf67c89e6634fba61046d', 'Manajemen', '2025-10-30 03:12:54', '2025-10-30 03:12:54'),
(3, 'afrizal', '2b474387a481cd9de9fd34910b7e72a6', 'Pegawai', '2025-10-30 03:13:29', '2025-10-30 03:13:29'),
(4, 'ikhsan', 'b2ab8163dc9a4ffdb8dcea1b0a4230f4', 'Manajemen', '2025-10-30 03:23:01', '2025-10-30 03:23:01'),
(5, 'audi', 'bdd1f5767dba6362fdede4f28159f62d', 'Pegawai', '2025-10-30 06:59:11', '2025-10-30 06:59:11'),
(6, 'fikri', '19da9ebef1ca88a6cb3ffcb997054199', 'Pegawai', '2025-10-31 09:13:19', '2025-10-31 09:13:19'),
(7, 'hayati', '61ccc765584d384c8dc99e46318893e9', 'Pegawai', '2025-11-02 11:56:28', '2025-11-02 11:56:28'),
(8, 'rafli', '79ece3a5487d0945cd1cd28a2b483c84', 'Pegawai', '2025-11-02 11:56:54', '2025-11-02 11:56:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`),
  ADD KEY `idx_role` (`role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
